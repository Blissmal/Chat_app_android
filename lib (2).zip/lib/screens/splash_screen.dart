import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../services/database_service.dart';
import 'login_screen.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _isInitialized = false;
  String? _userId;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    try {
      print('✅ SplashScreen initialized');

      // Small delay to prevent frame skips
      await Future.delayed(const Duration(milliseconds: 300));

      final authService = Provider.of<AuthService>(context, listen: false);
      final currentUser = authService.currentUser;

      if (currentUser != null) {
        setState(() {
          _userId = currentUser.uid;
          _isInitialized = true;
        });

        // Set user online in background (don't await to avoid blocking)
        final databaseService = Provider.of<DatabaseService>(context, listen: false);
        databaseService.setUserOnline(currentUser.uid).catchError((e) {
          print('⚠️ Could not set user online: $e');
        });
      } else {
        setState(() {
          _isInitialized = true;
        });
      }
    } catch (e) {
      print('❌ SplashScreen error: $e');
      setState(() {
        _isInitialized = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.chat_bubble,
                size: 80,
                color: Theme.of(context).primaryColor,
              ),
              const SizedBox(height: 24),
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              const Text(
                'Loading...',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            ],
          ),
        ),
      );
    }

    // User is logged in
    if (_userId != null) {
      return const HomeScreen();
    }

    // User is not logged in
    return const LoginScreen();
  }
}