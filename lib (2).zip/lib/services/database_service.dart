import 'package:firebase_database/firebase_database.dart';
import '../models/user.dart';
import '../models/chat.dart';
import '../models/message.dart';

class DatabaseService {
  final FirebaseDatabase _database = FirebaseDatabase.instance;

  // Cache for presence listeners to prevent multiple setups
  final Map<String, bool> _presenceListeners = {};

  // User operations
  Future<void> createUser(User user) async {
    try {
      await _database.ref('users/${user.id}').set(user.toMap());
    } catch (e) {
      rethrow;
    }
  }

  Future<User?> getUser(String userId) async {
    try {
      final snapshot = await _database.ref('users/$userId').get();
      if (snapshot.exists) {
        return User.fromMap(
          userId,
          Map<String, dynamic>.from(snapshot.value as Map),
        );
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  Stream<User?> getUserStream(String userId) {
    return _database.ref('users/$userId').onValue.map((event) {
      if (event.snapshot.exists) {
        return User.fromMap(
          userId,
          Map<String, dynamic>.from(event.snapshot.value as Map),
        );
      }
      return null;
    });
  }

  Future<void> updateUser(String userId, Map<String, dynamic> updates) async {
    try {
      await _database.ref('users/$userId').update(updates);
    } catch (e) {
      rethrow;
    }
  }

  Stream<List<User>> getAllUsersStream() {
    return _database.ref('users').onValue.map((event) {
      final List<User> users = [];
      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        data.forEach((key, value) {
          users.add(User.fromMap(key, Map<String, dynamic>.from(value as Map)));
        });
      }
      return users;
    });
  }

  // Presence system - Update user online status
  Future<void> setUserOnline(String userId) async {
    // Prevent multiple listeners for same user
    if (_presenceListeners.containsKey(userId)) {
      return;
    }

    try {
      final userStatusRef = _database.ref('users/$userId');

      // Set user as online immediately (fire and forget)
      userStatusRef.update({
        'status': 'online',
        'lastSeen': ServerValue.timestamp,
      });

      // Set up offline detection asynchronously
      _presenceListeners[userId] = true;

      final connectedRef = _database.ref('.info/connected');
      connectedRef.onValue.listen((event) {
        if (event.snapshot.value == true) {
          userStatusRef.onDisconnect().update({
            'status': 'offline',
            'lastSeen': ServerValue.timestamp,
          });
        }
      });
    } catch (e) {
      print('⚠️ setUserOnline error: $e');
    }
  }

  Future<void> setUserOffline(String userId) async {
    try {
      await _database.ref('users/$userId').update({
        'status': 'offline',
        'lastSeen': ServerValue.timestamp,
      });
      _presenceListeners.remove(userId);
    } catch (e) {
      rethrow;
    }
  }

  // Chat operations - Find existing chat or create new one
  Future<String?> findExistingChat(String userId1, String userId2) async {
    try {
      final snapshot = await _database.ref('chats').get();
      if (snapshot.exists) {
        final data = snapshot.value as Map<dynamic, dynamic>;

        for (var entry in data.entries) {
          final chatData = Map<String, dynamic>.from(entry.value as Map);
          final participants = List<String>.from(chatData['participants'] ?? []);

          // Check if this chat has exactly these two participants
          if (participants.length == 2 &&
              participants.contains(userId1) &&
              participants.contains(userId2)) {
            return entry.key as String;
          }
        }
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  Future<String> createChat(List<String> participants) async {
    try {
      // First, check if a chat already exists between these participants
      if (participants.length == 2) {
        final existingChatId = await findExistingChat(participants[0], participants[1]);
        if (existingChatId != null) {
          return existingChatId;
        }
      }

      // Create new chat only if it doesn't exist
      final chatRef = _database.ref('chats').push();
      await chatRef.set({
        'participants': participants,
        'lastMessageTime': ServerValue.timestamp,
      });
      return chatRef.key!;
    } catch (e) {
      rethrow;
    }
  }

  Future<Chat?> getChat(String chatId) async {
    try {
      final snapshot = await _database.ref('chats/$chatId').get();
      if (snapshot.exists) {
        return Chat.fromMap(chatId, Map<String, dynamic>.from(snapshot.value as Map));
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  Stream<List<Chat>> getUserChatsStream(String userId) {
    return _database.ref('chats').onValue.map((event) {
      final List<Chat> chats = [];
      final Set<String> seenChatIds = {}; // Prevent duplicates

      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        data.forEach((key, value) {
          final chat = Chat.fromMap(
            key,
            Map<String, dynamic>.from(value as Map),
          );

          // Only add if user is participant and chat not already added
          if (chat.participants.contains(userId) && !seenChatIds.contains(key)) {
            chats.add(chat);
            seenChatIds.add(key);
          }
        });

        // Sort by last message time
        chats.sort((a, b) =>
            (b.lastMessageTime ?? 0).compareTo(a.lastMessageTime ?? 0));
      }
      return chats;
    });
  }

  // Message operations
  Future<void> sendMessage(Message message) async {
    try {
      final messageRef = _database.ref('messages/${message.chatId}').push();
      await messageRef.set(message.toMap());

      // Update chat last message
      await _database.ref('chats/${message.chatId}').update({
        'lastMessage': message.text,
        'lastMessageTime': message.timestamp,
        'lastMessageSenderId': message.senderId,
      });

      // Create notification in background (don't block)
      _createMessageNotification(message);
    } catch (e) {
      rethrow;
    }
  }

  // Private method to create notification without blocking
  void _createMessageNotification(Message message) async {
    try {
      final chat = await getChat(message.chatId);
      if (chat != null) {
        final otherUserId = chat.participants.firstWhere(
              (id) => id != message.senderId,
          orElse: () => '',
        );

        if (otherUserId.isNotEmpty) {
          final sender = await getUser(message.senderId);
          if (sender != null) {
            await createNotification(
              userId: otherUserId,
              fromUserId: message.senderId,
              type: 'message',
              message: '${sender.name}: ${message.text}',
            );
          }
        }
      }
    } catch (e) {
      print('⚠️ Could not create notification: $e');
    }
  }

  Stream<List<Message>> getChatMessagesStream(String chatId) {
    return _database
        .ref('messages/$chatId')
        .orderByChild('timestamp')
        .onValue
        .map((event) {
      final List<Message> messages = [];
      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        data.forEach((key, value) {
          messages.add(Message.fromMap(key, Map<String, dynamic>.from(value as Map)));
        });
        messages.sort((a, b) => a.timestamp.compareTo(b.timestamp));
      }
      return messages;
    });
  }

  Future<void> markMessageAsRead(String chatId, String messageId) async {
    try {
      await _database.ref('messages/$chatId/$messageId').update({
        'isRead': true,
      });
    } catch (e) {
      rethrow;
    }
  }

  // Notification operations
  Future<void> createNotification({
    required String userId,
    required String fromUserId,
    required String type,
    String? message,
  }) async {
    try {
      final notifRef = _database.ref('notifications/$userId').push();
      await notifRef.set({
        'fromUserId': fromUserId,
        'type': type,
        'message': message,
        'timestamp': ServerValue.timestamp,
        'isRead': false,
      });
    } catch (e) {
      rethrow;
    }
  }

  Stream<List<Map<String, dynamic>>> getNotificationsStream(String userId) {
    return _database
        .ref('notifications/$userId')
        .orderByChild('timestamp')
        .onValue
        .map((event) {
      final List<Map<String, dynamic>> notifications = [];
      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        data.forEach((key, value) {
          final notif = Map<String, dynamic>.from(value as Map);
          notif['id'] = key;
          notifications.add(notif);
        });
        notifications.sort((a, b) =>
            (b['timestamp'] ?? 0).compareTo(a['timestamp'] ?? 0));
      }
      return notifications;
    });
  }

  Future<void> markNotificationAsRead(String userId, String notificationId) async {
    try {
      await _database.ref('notifications/$userId/$notificationId').update({
        'isRead': true,
      });
    } catch (e) {
      rethrow;
    }
  }

  Future<void> clearAllNotifications(String userId) async {
    try {
      await _database.ref('notifications/$userId').remove();
    } catch (e) {
      rethrow;
    }
  }
}