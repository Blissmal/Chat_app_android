import 'package:firebase_database/firebase_database.dart';
import '../models/user.dart';
import '../models/chat.dart';
import '../models/message.dart';

class DatabaseService {
  final FirebaseDatabase _database = FirebaseDatabase.instance;

  // User operations
  Future<void> createUser(User user) async {
    try {
      await _database.ref('users/${user.id}').set(user.toMap());
    } catch (e) {
      rethrow;
    }
  }

  Future<User?> getUser(String userId) async {
    try {
      final snapshot = await _database.ref('users/$userId').get();
      if (snapshot.exists) {
        return User.fromMap(
          userId,
          Map<String, dynamic>.from(snapshot.value as Map),
        ); // modified
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  Stream<User?> getUserStream(String userId) {
    return _database.ref('users/$userId').onValue.map((event) {
      if (event.snapshot.exists) {
        return User.fromMap(
          userId,
          Map<String, dynamic>.from(event.snapshot.value as Map),
        ); // modified
      }
      return null;
    });
  }

  Future<void> updateUser(String userId, Map<String, dynamic> updates) async {
    try {
      await _database.ref('users/$userId').update(updates);
    } catch (e) {
      rethrow;
    }
  }

  Stream<List<User>> getAllUsersStream() {
    return _database.ref('users').onValue.map((event) {
      final List<User> users = [];
      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        data.forEach((key, value) {
          users.add(User.fromMap(key, Map<String, dynamic>.from(value as Map),)); // modified
        });
      }
      return users;
    });
  }

  // Chat operations
  Future<String> createChat(List<String> participants) async {
    try {
      final chatRef = _database.ref('chats').push();
      await chatRef.set({
        'participants': participants,
        'lastMessageTime': ServerValue.timestamp,
      });
      return chatRef.key!;
    } catch (e) {
      rethrow;
    }
  }

  Future<Chat?> getChat(String chatId) async {
    try {
      final snapshot = await _database.ref('chats/$chatId').get();
      if (snapshot.exists) {
        return Chat.fromMap(chatId, Map<String, dynamic>.from(snapshot.value as Map)); // modified
      }
      return null;
    } catch (e) {
      rethrow;
    }
  }

  Stream<List<Chat>> getUserChatsStream(String userId) {
    return _database.ref('chats').onValue.map((event) {
      final List<Chat> chats = [];
      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        data.forEach((key, value) {
          final chat = Chat.fromMap(
            key,
            Map<String, dynamic>.from(value as Map),
          ); // modified
          if (chat.participants.contains(userId)) {
            chats.add(chat);
          }
        });
        chats.sort((a, b) => 
          (b.lastMessageTime ?? 0).compareTo(a.lastMessageTime ?? 0));
      }
      return chats;
    });
  }

  // Message operations
  Future<void> sendMessage(Message message) async {
    try {
      final messageRef = _database.ref('messages/${message.chatId}').push();
      await messageRef.set(message.toMap());

      // Update chat last message
      await _database.ref('chats/${message.chatId}').update({
        'lastMessage': message.text,
        'lastMessageTime': message.timestamp,
        'lastMessageSenderId': message.senderId,
      });
    } catch (e) {
      rethrow;
    }
  }

  Stream<List<Message>> getChatMessagesStream(String chatId) {
    return _database
        .ref('messages/$chatId')
        .orderByChild('timestamp')
        .onValue
        .map((event) {
      final List<Message> messages = [];
      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        data.forEach((key, value) {
          messages.add(Message.fromMap(key, Map<String, dynamic>.from(value as Map), // modified
          ));
        });
        messages.sort((a, b) => a.timestamp.compareTo(b.timestamp));
      }
      return messages;
    });
  }

  Future<void> markMessageAsRead(String chatId, String messageId) async {
    try {
      await _database.ref('messages/$chatId/$messageId').update({
        'isRead': true,
      });
    } catch (e) {
      rethrow;
    }
  }

  // Notification operations
  Future<void> createNotification({
    required String userId,
    required String fromUserId,
    required String type,
    String? message,
  }) async {
    try {
      final notifRef = _database.ref('notifications/$userId').push();
      await notifRef.set({
        'fromUserId': fromUserId,
        'type': type,
        'message': message,
        'timestamp': ServerValue.timestamp,
        'isRead': false,
      });
    } catch (e) {
      rethrow;
    }
  }

  Stream<List<Map<String, dynamic>>> getNotificationsStream(String userId) {
    return _database
        .ref('notifications/$userId')
        .orderByChild('timestamp')
        .onValue
        .map((event) {
      final List<Map<String, dynamic>> notifications = [];
      if (event.snapshot.exists) {
        final data = event.snapshot.value as Map<dynamic, dynamic>;
        data.forEach((key, value) {
          final notif = Map<String, dynamic>.from(value as Map);
          notif['id'] = key;
          notifications.add(notif);
        });
        notifications.sort((a, b) => 
          (b['timestamp'] ?? 0).compareTo(a['timestamp'] ?? 0));
      }
      return notifications;
    });
  }
}
